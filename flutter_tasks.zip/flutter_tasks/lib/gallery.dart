import 'dart:io';
import 'package:flutter/material.dart';
import 'package:photo_view/photo_view_gallery.dart';
import 'package:photo_view/photo_view.dart';


class Gallery extends StatefulWidget{

  int initialIndex = 0;
  List<String> paths = [];

  @override
  State createState()=>new GalleryState(initial: initialIndex, paths: paths);
  
  Gallery({int initial, List<String> paths}){
    initialIndex = initial;
    this.paths = paths;
  }
  
}

class GalleryState extends State<Gallery>{

  int initialIndex = 0;
  List<String> paths = [];
  
  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      //appBar: new PreferredSize(child: null, preferredSize: new Size(0,0)),
      body: new Container(
          child: PhotoViewGallery.builder(
            scrollPhysics: const BouncingScrollPhysics(),
            builder: (BuildContext context, int index) {
              return PhotoViewGalleryPageOptions(
                imageProvider: new FileImage(new File(paths[index])),
                initialScale: PhotoViewComputedScale.contained,
                heroTag: paths[index],
              );
            },
            itemCount: paths.length,
            loadingChild: new Center(
              child: new FractionallySizedBox(
                widthFactor: 0.2,
                heightFactor: 0.2,
                child: new CircularProgressIndicator(),
              ),
            ),
            pageController: new PageController(initialPage: initialIndex),
          ),
        ),
    );
  }
  
  GalleryState({int initial, List<String> paths}){
    initialIndex = initial;
    this.paths = paths;
  }
}