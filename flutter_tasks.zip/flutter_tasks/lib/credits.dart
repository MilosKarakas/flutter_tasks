import 'package:flutter/material.dart';


class CreditsPage extends StatefulWidget{

  @override
  State createState()=>CreditsPageState();

}

class CreditsPageState extends State<CreditsPage>{

  @override
  Widget build(BuildContext context) {
    return new Container();
  }
}